#include "Analytics.h"

#include <cmath>
#include <iostream>

/* PUBLIC
   Analytics Constructor uses its parameters to resize BinData and set BindWidth.*/
Analytics::Analytics(double Left, double Right, unsigned int Bins) : LeftBoundary(Left), RightBoundary(Right), NumberOfBins(Bins){
    clear();
        
    if(Right <= Left) fatalError("Histogram::Histogram(). Called with right <= left.");
    if(Bins == 0) fatalError("Histogram::Histogram(). Called with nBins == 0.");

    BinWidth = (Right-Left) / Bins;
	
    /* Histogram will contain nBins between left and right.
       There will also be 2 overspill bins, one for data < left, and one for data >= right.*/
    BinData.resize(Bins+2);
    }
            
/* PUBLIC
   Calculate Kurtosis of winding angles.*/
const double Analytics::calculateKurtosis(){
    return double ((NumberOfAngles)*M4 / (M2*M2)) - 3.0;
    }

/* PUBLIC
   Calculate Mean of winding angles.*/
const double Analytics::calculateMean(){
    return M1;
    }

/* PUBLIC
   Calculate Variance of winding angles in radians.*/
const double Analytics::calculateRadianVariance(){
    return radian_M2/(NumberOfAngles-1.0);
    }

/* PUBLIC
   Calculate Skewness of winding angles.*/
const double Analytics::calculateSkewness(){
    return sqrt(double(NumberOfAngles)) * M3 / pow(M2, 1.5);
    }

/* PUBLIC
   Calculate Standard Deviation of winding angles.*/
const double Analytics::calculateStandardDeviation(){
    return sqrt( calculateVariance() );
    }

/* PUBLIC
   Calculate Variance of winding angles.*/
const double Analytics::calculateVariance(){    
    return M2/(NumberOfAngles-1.0);
    }

/* PUBLIC
   Clear intermediates and number of data values.*/
void Analytics::clear(){
    NumberOfAngles = 0;
    M1 = M2 = M3 = M4 = radian_M2 = 0.0;

    return;
    }
    
/* PUBLIC
   Format results in Histogram.*/
const void Analytics::getHistogramResults(vector<double>& binBoundaries, vector<long>& binData){
    binBoundaries.resize(NumberOfBins + 2);
   
    for (unsigned int i = 0; i <= NumberOfBins; ++i){
        binBoundaries[i] = LeftBoundary + static_cast<double>(i) * BinWidth;
        }
    
    binBoundaries[NumberOfBins + 1] = VERY_BIG;
	
    binData = BinData;	//	Copy the whole vector

    return;
    }
    
/* PUBLIC
   Output Analytics to Stream.*/ 
void Analytics::outputResults(std::string AnalyticResults, unsigned int Steps){
    ofstream AnalyticResultsOutput(AnalyticResults);

    std::cout<<TAB1<<AnalyticResults<<std::endl;

	if (!AnalyticResultsOutput){
        std::cout<<"Failed to open the file."<<std::endl;
        }
	else{
        AnalyticResultsOutput << "Excess_Kurtosis" << ", " << "Kurtosis" << ", " << "Variance" << ", " << "Radian_Variance" << ", " << "Mean" << ", " << "Steps" << std::endl;
        AnalyticResultsOutput << calculateKurtosis() << ", " << calculateKurtosis()+3 << ", " << calculateVariance() << ", " << calculateRadianVariance() << ", " << M1 << ", " << Steps << std::endl;
        AnalyticResultsOutput.close();
        }
    
    return;
    }
    
/* PUBLIC
   Calculate intermediate terms for analytics without storing individual winding angles.*/ 
void Analytics::push(float x){
    double delta, delta_n, delta_n2, term1, radian_term1;
    long long n1 = NumberOfAngles;
    NumberOfAngles++;
    delta = x - M1;
    delta_n = delta / NumberOfAngles;
    delta_n2 = delta_n * delta_n;
    term1 = delta * delta_n * n1;
    radian_term1 = (delta*(PI/180)) * (delta_n*(PI/180)) * n1;
    M1 += delta_n;
    M4 += term1 * delta_n2 * (NumberOfAngles*NumberOfAngles - 3*NumberOfAngles + 3) + 6 * delta_n2 * M2 - 4 * delta_n * M3;
    M3 += term1 * delta_n * (NumberOfAngles - 2) - 3 * delta_n * M2;
    M2 += term1;
    radian_M2 += radian_term1;
    
    //Histogram: Note that if x lies on a boundary, then it gets put in the bin to the RIGHT.
    if ( x < LeftBoundary ){
        ++BinData[0];
	}
	else if ( x >= RightBoundary ){
        ++BinData[NumberOfBins + 1];
	}
	else{
        const int iBin = static_cast<int>((x - LeftBoundary) / BinWidth) + 1;
        ++BinData[iBin];
        }    

    return;
    }

/* PUBLIC
   Return the number of data values pushed to Analytics Class.*/
const long long Analytics::returnNumberOfDataValues(){
    return NumberOfAngles;
    }

/* PUBLIC
   Output Histogram to Stream.*/
const void Analytics::writeHistogramToStream(std::string HistogramResults){
    ofstream HistogramResultsOutput(HistogramResults);

    std::cout<<TAB1<<HistogramResults<<std::endl;
        
	if(!HistogramResultsOutput){
        std::cout<<"Failed to open the file."<<std::endl;
        }
	else{
	    vector<double> binBoundaries;
	    vector<long> binData;
	    getHistogramResults(binBoundaries, binData);

	    vector<double>::const_iterator BoundaryIterator = binBoundaries.begin();
	    vector<long>::const_iterator DataIterator = binData.begin();

	    for( ; BoundaryIterator != binBoundaries.end(); ++BoundaryIterator, ++DataIterator ){
		    HistogramResultsOutput << setw(10) << *BoundaryIterator << ", " << setw(10) << *DataIterator << std::endl;
	        }
        
        HistogramResultsOutput.close();
        }

    return;
    }