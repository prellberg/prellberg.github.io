#ifndef ANALYTICS_H
    #define ANALYTICS_H

    #include "RandomWalkCommonHeader.h"

    #include "stdlib.h"

    #include <iomanip>
    #include <iostream>
    #include <vector>

    class Analytics{       
        public:
            Analytics(double Left, double Right, unsigned int Bins);
            const double calculateKurtosis();
            const double calculateMean();
            const double calculateRadianVariance();
            const double calculateSkewness();
            const double calculateStandardDeviation();
            const double calculateVariance();
            const long long returnNumberOfDataValues();
            void clear();
            const void getHistogramResults(std::vector<double>& binBoundaries, std::vector<long>& binData);
            void outputResults(std::string AnalyticResults, unsigned int Steps);
            void push(float x);
            const void writeHistogramToStream(std::string HistogramResults);

        private:
            const double LeftBoundary;
            const double RightBoundary;
            const unsigned long NumberOfBins;

            double BinWidth;
            double M1, M2,radian_M2, M3, M4;
            long long NumberOfAngles;
            vector<long> BinData;
        };
#endif