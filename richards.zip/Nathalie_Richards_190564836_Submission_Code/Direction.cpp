#include "Direction.h"
#include "Grid.h"

// Define static member variables
std::vector<bool> Direction::JustLeftCentre; 
signed int Direction::CentreTransitChanges[4][4][2] = { { {-ThreeSixty,ThreeSixty},{-Ninety,-Ninety},{-OneEighty,OneEighty},{Ninety,Ninety} },
                                                       { {Ninety,Ninety},{-ThreeSixty,ThreeSixty},{-Ninety,-Ninety},{-OneEighty,OneEighty} },
                                                       { {-OneEighty,OneEighty},{Ninety,Ninety},{-ThreeSixty,ThreeSixty},{-Ninety,-Ninety} },
                                                       { {-Ninety,-Ninety},{-OneEighty,OneEighty},{Ninety,Ninety},{-ThreeSixty,ThreeSixty} } };
std::vector<signed int> Direction::PartialRotationEnteringTransit; 
std::vector<signed int> Direction::TransitChange; 

/* PUBLIC
   Direction Constructor. By setting its member variables equal to passed parameters, its subclasses get their differemt behaviours.*/
Direction::Direction(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment){
    GoingInDirection = CompassPoint;
    CameFromDirection = (GoingInDirection + 2) % 4;
    SolutionGrid = ThisGrid;
    this->Adjustment=Adjustment;

    if(JustLeftCentre.size()!=omp_get_max_threads()) JustLeftCentre.resize(omp_get_max_threads(), FALSE);
    if(PartialRotationEnteringTransit.size()!=omp_get_max_threads()) PartialRotationEnteringTransit.resize(omp_get_max_threads(), 0); 
    if(TransitChange.size()!=omp_get_max_threads()) TransitChange.resize(omp_get_max_threads(), 0);   
    }

/* PUBLIC
   Derived class constructors simply invoke the base class (Direction) constructor.*/
DirectionError::DirectionError(Grid* ThisGrid, unsigned short int CompassPoint,unsigned short int Adjustment) : Direction(ThisGrid, CompassPoint, Adjustment){} 
East::East(Grid* ThisGrid, unsigned short int CompassPoint,unsigned short int Adjustment): Direction(ThisGrid, CompassPoint, Adjustment){}  
North::North(Grid* ThisGrid, unsigned short int CompassPoint,unsigned short int Adjustment): Direction(ThisGrid, CompassPoint, Adjustment){} 
South::South(Grid* ThisGrid, unsigned short int CompassPoint,unsigned short int Adjustment): Direction(ThisGrid, CompassPoint, Adjustment){} 
West::West(Grid* ThisGrid, unsigned short int CompassPoint,unsigned short int Adjustment): Direction(ThisGrid, CompassPoint, Adjustment){} 

/* PUBLIC
   This function is needed to reset the Direction classes static state variables which are shared by all sub class instances.*/
void Direction::reset(){
    JustLeftCentre[SolutionGrid->Thread] = FALSE; 
    PartialRotationEnteringTransit[SolutionGrid->Thread] = 0; 
    TransitChange[SolutionGrid->Thread] = 0; 
    }

/* PUBLIC
   This function is needed because Length isn't known when the subclasses of Direction are created and the Direction constructor is called.*/
void Direction::setStepSize(unsigned int Length){
    StepSize = Length;
    }

/* PUBLIC
   This key function is not overriden by the derived classes East, North, South and West.
   However, the derived classes have different behaviour due the specific values of their member attributes.*/
Direction* Direction::takeOneStep(unsigned int& Step, unsigned int& Position, signed long& CurrentWindingAngle, signed long& UpdatedWindingAngle, bool& WalkLoopEncountered){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        // When displaying execution time, we will need to break out the times for initialiseWalk, getNewDirection navigate and reset.
        clock_t LocalTimer = clock();
    #endif

    #if ENABLE_VERBOSE_MODE() || ENABLE_ANALYSIS_MODE()
        std::string News;
        signed int CurrentX = 0; // Only used for displaying useful information.
        signed int CurrentY = 0; // Only used for displaying useful information.
        std::string ArrivalText = ". ERROR: Somehow this text has not been updated. Position: ";
    #endif

    signed long ChangeInWindingAngle;

    // 1. Update GridMapTrace.at(Position) with GoingInDirection.
    SolutionGrid->GridMapTrace.at(Position) += GoingInDirection;
    #if ENABLE_VERBOSE_MODE()
        //std::cout<<" Position status on leaving: "<<SolutionGrid->GridMapTrace.at(Position)<<"."<<std::endl;
        News="Postion status on leaving: " + to_string(SolutionGrid->GridMapTrace.at(Position)) + "\n\n";
        SolutionGrid->Reporter.at((2*Step)-1)=News;
    #endif

    // 2. Take Step
    Position += StepSize;

    // 3. Evaluate the transit history of the new position.
    if(Position != SolutionGrid->Centre){    
        // We are not back at the centre.
        if(SolutionGrid->GridMapTrace.at(Position) == UNVISITED){
            // 3.a Arriving at this off centre position for the first time.
            #if ENABLE_VERBOSE_MODE()
                ArrivalText = ". New position: ";
            #endif

            // 3.a.1. Calculate the change in winding angle.
            // 3.a.1.i. Determine if this is the very first step. 
            if(Step == 1){
                ChangeInWindingAngle = (signed long)SolutionGrid->GridMap.at(Position) - (signed long)SolutionGrid->GridMap.at(Position-StepSize);
                /* Ensure that future steps know we have not just left the centre.
                   Note that the following line is not really required since reset() sets JustLeftCentre to FALSE,
                   as does the JustLeftCentre.resize() call in the constructor.*/
                JustLeftCentre[SolutionGrid->Thread] = FALSE;
                }
            // 3.a.1.ii. Determine if we have just passed back through the centre.
            else if (JustLeftCentre[SolutionGrid->Thread] == TRUE){
                ChangeInWindingAngle = TransitChange[SolutionGrid->Thread] + PartialRotationEnteringTransit[SolutionGrid->Thread];

                // Ensure that future steps know we have not just left the centre.
                JustLeftCentre[SolutionGrid->Thread] = FALSE;
                }
            // 3.a.1.iii. An ordinary step.
            else{
                ChangeInWindingAngle = (signed long)SolutionGrid->GridMap.at(Position) - (signed long)SolutionGrid->GridMap.at(Position-StepSize);

                // We need to adjust for any movement across the 0:2*Pi boundary
                if(ChangeInWindingAngle > SolutionGrid->BoundaryTest) ChangeInWindingAngle = ChangeInWindingAngle - (signed long)(2*SolutionGrid->PiAsUnsignedInt);
                else if(ChangeInWindingAngle < -SolutionGrid->BoundaryTest) ChangeInWindingAngle = ChangeInWindingAngle + (signed long)(2*SolutionGrid->PiAsUnsignedInt);
                }

            /* 3.a.2. Use CameFromDirection (equals GoingInDirection looking backwards).
               NOTE: This is plain =, not += . This is different from below.*/
            SolutionGrid->GridMapTrace.at(Position) = CameFromDirection;

            // 3.a.3. Change Direction with random selection.
   
            #if ENABLE_ANALYSIS_MODE()
                /* Investigation of behavioural variance with Professor's code.
                Investigate random generation of changes of direction.*/
                Choice = SolutionGrid->DirectionChoices.at(nextRandomDirectionChange(SolutionGrid->ProbabilityPoints));     
                switch (Choice){
                    case GO_STRAIGHT_ON: SolutionGrid->GoStraightOn += 1; break;
                    case GO_RIGHT: SolutionGrid->TurnRight += 1; break;
                    case GO_LEFT: SolutionGrid-> TurnLeft += 1;break;
                    default: SolutionGrid->OtherDirectionChange += 1;
                }
                
                if(Choice == GO_STRAIGHT_ON) NowFacing = GoingInDirection;
                else NowFacing = (GoingInDirection + Choice + Adjustment) % 4;
            #else
                Choice = SolutionGrid->DirectionChoices.at(nextRandomDirectionChange(SolutionGrid->ProbabilityPoints));
                // The normal case. No analysis. No testing. Just a standard run
                if(Choice == GO_STRAIGHT_ON) NowFacing =GoingInDirection;
                else NowFacing = (GoingInDirection + Choice +Adjustment) % 4;
            #endif

            }
        else{
            // 3.b. Arriving at this off centre position for the second time.
            #if ENABLE_VERBOSE_MODE()
                ArrivalText = ". Previously visited off centre position: ";
            #endif

            // 3.b.1. Calculate the change in winding angle. Note we do not need to test for STEP == 0
            // 3.b.1.i. Determine if we have just passed back through the centre.
            if (JustLeftCentre[SolutionGrid->Thread] == TRUE){ 
                ChangeInWindingAngle = TransitChange[SolutionGrid->Thread] + PartialRotationEnteringTransit[SolutionGrid->Thread]; 

                // Ensure that future steps know we have not just left the centre.
                JustLeftCentre[SolutionGrid->Thread] = FALSE; 
                }
            // 3.b.1.ii. An ordinary step.
            else{
                ChangeInWindingAngle = (signed long)SolutionGrid->GridMap.at(Position) - (signed long)SolutionGrid->GridMap.at(Position-StepSize);

                // We need to adjust for any movement across the 0:2*Pi boundary
                if(ChangeInWindingAngle > SolutionGrid->BoundaryTest) ChangeInWindingAngle = ChangeInWindingAngle - (signed long)(2*SolutionGrid->PiAsUnsignedInt);
                else if(ChangeInWindingAngle < -SolutionGrid->BoundaryTest) ChangeInWindingAngle = ChangeInWindingAngle + (signed long)(2*SolutionGrid->PiAsUnsignedInt);
                }

            /* 3.b.2. Use CameFromDirection (equals GoingInDirection looking backwards).
               NOTE: This is +=, not plain = . This is different from above.*/
            SolutionGrid->GridMapTrace.at(Position) += CameFromDirection;
    
            // 3.b.3. Change Direction by subtraction from VISITED_TWICE.
            NowFacing = VISITED_TWICE - SolutionGrid->GridMapTrace.at(Position);
            }
        }
    else{
        // 3.c.1. For testing /analysis purposes we keep track of all the times we have returned to the Centre for the entire run.
        SolutionGrid->ReturnsToCentre += 1; 

        // 3.c.2. Determine the change in winding angle. For the return to centre step, this is the partial or fractional loop rotation value.
        ChangeInWindingAngle = -(CurrentWindingAngle) % (2*SolutionGrid->PiAsUnsignedInt);

        /* 3.c.3. Use CameFromDirection (equals GoingInDirection looking backwards).
           NOTE: This is +=, not plain = . This is different from above.*/
        SolutionGrid->GridMapTrace.at(Position) += CameFromDirection;
    
        // 3.c.4. The normal case. No analysis. No testing. Just a standard run.
        Choice = SolutionGrid->DirectionChoices.at(nextRandomDirectionChange(SolutionGrid->ProbabilityPoints));
        // The normal case. No analysis. No testing. Just a standard run
        if(Choice==GO_STRAIGHT_ON)NowFacing =GoingInDirection;
        else NowFacing = (GoingInDirection + Choice +Adjustment) % 4;
                    
        // 3.c.5. Determine whether we are back for the first time (or the second and last time).
        if(SolutionGrid->GridMapTrace.at(Position) < VISITED_TWICE && (NowFacing != SolutionGrid->FirstStep)){
            // 3.c.5.i. We are back at the centre for the first time.
            #if ENABLE_VERBOSE_MODE()
                ArrivalText = ". Back at Centre (Starting) position for the first time: ";
            #endif

            // 3.c.5.i.2. We need to determine the angle of rotation at the point of reaching the centre.
            unsigned short int DirectionOfRotation;
            if(CurrentWindingAngle > 0) DirectionOfRotation = COUNTER_CLOCKWISE; else DirectionOfRotation = CLOCKWISE;

            // 3.c.5.i.3. We need to select the change of direction that must be supplied and store it where it can be obtained next step.
            TransitChange[SolutionGrid->Thread] = CentreTransitChanges[CameFromDirection][NowFacing][DirectionOfRotation];

            // 3.c.5.i.4. We need to store the partial angle where it can be obtained next step.
            PartialRotationEnteringTransit[SolutionGrid->Thread] = (signed int) -ChangeInWindingAngle;

            // 3.c.5.i.5. Finally, we need to flag for the next step that we have just left the centre. 
            JustLeftCentre[SolutionGrid->Thread] = TRUE;
            }
        else{
            // 3.c.5.ii. We are back at the centre for the second time.
            #if ENABLE_VERBOSE_MODE()
                ArrivalText = ". Back at Centre (Starting) position for the second time: ";
            #endif

            // 3.c.5.ii.1. In order for both the display of NowFacing and the return line to function properly, we must have a valid NowFacing.*/
            NowFacing = CameFromDirection;

            // 3.c.5.ii.2 We must set the LoopEncountered flag = TRUE.
            WalkLoopEncountered = TRUE;

            // 3.c.5.ii.3 Increment LoopsEncountered and, for interest, update the aggregate loop length so that we can later calcuate the average.
            SolutionGrid->LoopsEncountered += 1;
            SolutionGrid->AggregateLoopLength += Step;
            }
        }

    // 4. Update Winding Angle
    UpdatedWindingAngle = (signed long) (CurrentWindingAngle + ChangeInWindingAngle);

    // 5. Return New Direction
    #if ENABLE_VERBOSE_MODE()
        SolutionGrid->updateCoordinates(*&CurrentX, *&CurrentY, *&Position);
        News = "     THREAD: " + to_string(SolutionGrid->Thread) + ". Step: " + to_string(Step) + ArrivalText + to_string(Position);
        News = News + " (" + to_string(CurrentX) + "," + to_string(CurrentY) + "). Came from the " + SolutionGrid->getDirectionAsText(CameFromDirection);
        News = News + ". Position status having arrived: " + to_string(SolutionGrid->GridMapTrace.at(Position)) + ".\n";
        News = News + TAB3 + "Change in winding angle: " + to_string(ChangeInWindingAngle) + ". Cumulative winding angle: " + to_string(UpdatedWindingAngle) + " (";
        News = News + to_string((float)(UpdatedWindingAngle / (pow(10,PRECISION_DECIMAL_POINTS)) * (180 / PI))) + ".\n";
        if(ArrivalText != ". Back at Centre (Starting) position for the second time: "){
            News = News + TAB3 + "Going " + SolutionGrid->getDirectionAsText(NowFacing) + ".";
            }
        SolutionGrid->Reporter.at(2*Step) = News;    
    #endif

    #if ENABLE_ANALYSIS_MODE()
        SolutionGrid->updateCoordinates(*&CurrentX, *&CurrentY, *&Position);
        SolutionGrid->trackGridUse(Step, CurrentX, CurrentY);     
    #endif

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        SolutionGrid->Logger.at(9).Invocations += 1;
        SolutionGrid->Logger.at(9).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return SolutionGrid->NewHeadings[GoingInDirection][NowFacing];    
    }

/* PUBLIC
   We need to override the base class virtual function to call fatalError in this case. All other derived classes use the base class virtual function.*/
Direction* DirectionError::takeOneStep(unsigned int& Step, unsigned int& Position, signed long& CurrentWindingAngle, signed long& UpdatedWindingAngle, bool& WalkLoopEncountered){
    fatalError("DirectionError::takeOneStep. Requested to retrace steps.");
    return this;
    }