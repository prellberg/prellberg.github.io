#ifndef Direction_h
    #define Direction_h

    #include "RandomWalkCommonHeader.h"
    class Grid;

    class Direction{
        public:
            Direction(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment);
            void reset();
            virtual void setStepSize(unsigned int Length);
            virtual Direction* takeOneStep(unsigned int& Step, unsigned int& Position, signed long& CurrentWindingAngle, signed long& UpdatedWindingAngle, bool& WalkLoopEncountered);

        protected:
            // All (instances of all) subclasses need to share the one single value of the following two variables.  
            // Required to show if the loop has just left the centre.
            static std::vector<bool> JustLeftCentre;
            /* This array (and associated four consts) is used to track changes of winding angle following transits through the centre;
               The first dimension represents CameFromDirection - the direction from which the Walk entered the centre.
               The second dimension represents NowFacing / - the direction in which the Walk will leave the centre.
               The second dimension represents the DirectionOfRotation - this does not change as a result of transit through the centre.
               The appropriate value is used to set CentreTransitChange at the grid point and it is used on the following set.
               This grid is used in conjunction with the static member bool JustLeftCentre.
               0 represents North, 1 East, 2 South and 3 West. 
               The rows below represent the CameFromDirection dimension.
               The in row braces represent the NowFacing dimension.
               The in brace value pairs represent the rotation dimension. The 0 element represents counter clockwise. The 1 element represents clockwise.   
               */
            const static signed int Ninety = floor(PI*pow(10,PRECISION_DECIMAL_POINTS))/2;   
            const static signed int OneEighty = floor(PI*pow(10,PRECISION_DECIMAL_POINTS));   
            const static signed int TwoSeventy = floor(PI*pow(10,PRECISION_DECIMAL_POINTS))*(3/2);   
            const static signed int ThreeSixty = floor(PI*pow(10,PRECISION_DECIMAL_POINTS))*2;   
            static signed int CentreTransitChanges[4][4][2];
            static std::vector<signed int> PartialRotationEnteringTransit; 
            static std::vector<signed int> TransitChange; 

            Grid* SolutionGrid;
            signed int StepSize;
            unsigned short int Adjustment;
            unsigned short int Choice;
            unsigned short int CameFromDirection;
            unsigned short int GoingInDirection;
            unsigned short int NowFacing;
        };

    class DirectionError : public Direction{
        public:
            DirectionError(Grid* ThisGrid, unsigned short int CompassPoint , unsigned short int Adjustment);
            Direction* takeOneStep(unsigned int& Step, unsigned int& Position, signed long& CurrentWindingAngle, signed long& UpdatedWindingAngle, bool& WalkLoopEncountered);
        };

    class East : public Direction{
        public:
            East(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment);
        };

    class North : public Direction{
        public:
            North(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment);
        };

    class South : public Direction{
        public:
            South(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment);
        };

    class West : public Direction{
        public:
            West(Grid* ThisGrid, unsigned short int CompassPoint, unsigned short int Adjustment);
        };
#endif