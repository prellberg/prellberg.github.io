#include "Grid.h"

/* PUBLIC
   Grid Constructor processes parameters passed to main() and then resizes its member vectors to the appropriate size.*/
Grid::Grid(unsigned int Steps, float Compression, float ProbabilityRight, float ProbabilityLeft,
    unsigned short int ProbabilityScaleFactor, unsigned short int ThreadNumber){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        // When displaying execution time, we will need to break out the times for initialiseLogger and setUpProbabilities.
        clock_t LocalTimer = clock();
        initialiseLogger();
    #endif

    // First capture constructor parameters
    Thread = ThreadNumber;
    GridCompression = Compression;
    setUpProbabilities(ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor);
    
    /* We add 1 to the length because we want to represent the x = 0 and y = 0 axes withing the grid.
       We add a further 2 to the length to create a 1 grid point safe zone all around the working grid
       The objective is to avoid an out of bounds error when we create the East, North, South and West vectors.*/ 

    Length = (unsigned int) (ceil(2*Steps*GridCompression)+1);
    // Note that WalkSteps is 1 bigger than the Steps in RandomWalk::main(). This is so that we can capture the centre point.
    WalkSteps = Steps + 1;

    if((Length % 2) == 0) Length += 1;
    GridPoints = Length*Length;
    Centre = (GridPoints - 1)/2;

    Walk.resize(WalkSteps);
    WalkPositionsVisited.resize(WalkSteps);
    GridMapTrace.resize(GridPoints,UNVISITED);
    Reporter.resize(WalkSteps*2, "");

    CentreX = CentreY = (Length-1)/2;

    BoundaryTest = ((3/2)*PiAsUnsignedInt)+1;

    FacingEast->setStepSize(Length);
    FacingNorth->setStepSize(1);
    FacingSouth->setStepSize(-1);
    FacingWest->setStepSize(-Length);
    RetracingSteps->setStepSize(0);
    
    /* The first [] indicates the direction the walk went in to get to current point,
        The second [] indicates the the walk is leaving in from the current point */
    NewHeadings[0][0] = FacingNorth; // Facing North, straight on
    NewHeadings[1][1] = FacingEast; // Facing East, straight on
    NewHeadings[2][2] = FacingSouth; // Facing South, straight on
    NewHeadings[3][3] = FacingWest; // Facing West, straight on

    NewHeadings[0][1] = FacingEast; // Facing North, turn right (Clockwise)
    NewHeadings[1][2] = FacingSouth; // Facing East, turn right (Clockwise)
    NewHeadings[2][3] = FacingWest; // Facing South, turn right (Clockwise)
    NewHeadings[3][0] = FacingNorth; // Facing West, turn right (Clockwise)

    NewHeadings[0][3] = FacingWest; // Facing North, turn left (Counter clockwise)
    NewHeadings[1][0] = FacingNorth; // Facing East, turn left (Counter clockwise)
    NewHeadings[2][1] = FacingEast; // Facing South, turn left (Counter clockwise)
    NewHeadings[3][2] = FacingSouth; // Facing West, turn left (Counter clockwise)

    NewHeadings[0][2] = RetracingSteps; // Facing North, turning 180 degrees
    NewHeadings[1][3] = RetracingSteps; // Facing East, turning 180 degrees
    NewHeadings[2][0] = RetracingSteps; // Facing South, turning 180 degrees
    NewHeadings[3][1] = RetracingSteps; // Facing West, turning 180 degrees

    // Some information is useful even when ENABLE_VERBOSE_MODE() is set to FALSE.
    std::cout<<TAB2<<"Grid Length: "<<Length<<", Grid Points: "<<GridPoints<<", Walk Steps including Step 0 (the centre): "<<WalkSteps<<"."<<std::endl;
    std::cout<<TAB2<<"Centre position: "<<Centre<<", Centre coordinates: ("<<CentreX<<","<<CentreY<<")."<<std::endl;

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(0).Invocations += 1;
        Logger.at(0).TotalExecutionTime += (clock() - LocalTimer);
    #endif
    }

/* PUBLIC
   This critical function finds solutions and returns them to the calling function (main()). It does not know how many solutions are required.
   It uses many of Grid's private member functions.*/
std::vector<signed long> Grid::findWalk(){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        // When displaying execution time, we will need to break out the times for initialiseWalk, reset and Direction::takeOneStep.
        clock_t LocalTimer = clock();
    #endif

    bool SolutionFound;
    bool WalkLoopEncountered;
    signed int CurrentX = 0; // Only used for displaying useful information.
    signed int CurrentY = 0; // Only used for displaying useful information.
    unsigned int LoopCounter = 0;
    unsigned int Position = 0;
    unsigned short int GoingInDirection = 0;
    unsigned short int NowFacing =0; // This represents a different grid point to GoingInDirection. Together they form a path across a grid point.

    Direction* FacingDirection;

    SolutionFound = FALSE;
    while(SolutionFound == FALSE){

        /* Set all Grid points to unvisited (0) apart from the centre (starting) position (0,0) which should be set to VISITED_TWICE (900).
           Note that we call this even for "Step 0, when the only affect is to set the centre (starting) position.
           This reset will also be executed if we have to restart following a loop encountered event.*/
        reset(*&LoopCounter);
        Position = WalkPositionsVisited.at(0) = Centre;
 
        if(initialiseWalk(*&GoingInDirection, *&NowFacing, *&Position) == FALSE) fatalError("Grid::findWalk. Inititalise Walk failed.");

        FacingDirection = NewHeadings[GoingInDirection][NowFacing];

        #if ENABLE_VERBOSE_MODE()
            updateCoordinates(*&CurrentX, *&CurrentY, *&WalkPositionsVisited.at(0));
            std::string News = "     THREAD: " + to_string(Thread) + ". Step: 0. Centre (starting) position:" + to_string(WalkPositionsVisited.at(0));
            News = News + " (" + to_string(CurrentX) + "," + to_string(CurrentY) + "). Position status after initialisation: " + to_string(GridMapTrace.at(WalkPositionsVisited.at(0))) + ".\n";
            News = News + TAB3 + "Change in winding angle: " + to_string(Walk.at(0)) + ". Cumulative winding angle: " + to_string(Walk.at(0)) + ".\n";
            News = News + TAB3 + "Going " + getDirectionAsText(GoingInDirection) + ".";
            Reporter.at(0) = News;       
        #endif

        LoopCounter = 1;
        WalkLoopEncountered = FALSE;
        while( (WalkLoopEncountered == FALSE) && (LoopCounter < WalkSteps) ){
            FacingDirection = FacingDirection->takeOneStep(LoopCounter, *&Position, Walk.at(LoopCounter-1), *&Walk.at(LoopCounter), *&WalkLoopEncountered);

            // We record the positions visited so that we can reset GridMapTrace after each solution is found.
            WalkPositionsVisited.at(LoopCounter) = Position;

            LoopCounter++;
            }

        /* We need to reset the grid following the successful identification of a solution or on encountering a loop.*/
        reset(*&LoopCounter);
        if(LoopCounter == WalkSteps) SolutionFound = TRUE;
        if(WalkLoopEncountered == TRUE) SolutionFound = FALSE;
        }

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(6).Invocations += 1;
        Logger.at(6).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    #if ENABLE_VERBOSE_MODE()
        for(int NewsItem = 0; NewsItem < Reporter.size(); NewsItem++) std::cout<<Reporter.at(NewsItem);
    #endif
    
    return Walk;
    }

/* PUBLIC
   This critical function determines the winding angle for each grid element.
   */
int Grid::initialise(clock_t& Timer, std::string Action){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        // When displaying execution time, we will need to break out the times for serialise and loadWindingAngles.
        clock_t LocalTimer = clock();
    #endif

    signed int VectorSize;
    signed int XCoordinate;
    signed int YCoordinate;
    unsigned int AbsoluteX;
    unsigned int AbsoluteY;

    if((Action == "serialise")|(Action =="RAM")){ // The only difference between serialise and RAM is that RAM doesnt output to file.
        std::cout<<TAB1<<"Creating angle change data at ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
        GridMap.resize(GridPoints);

        for(unsigned int LoopCounter = 0; LoopCounter < GridPoints; LoopCounter++){
            AbsoluteY = LoopCounter % Length;
            AbsoluteX = (LoopCounter - AbsoluteY) / Length; 
            XCoordinate = AbsoluteX - CentreX;
            YCoordinate = AbsoluteY - CentreY;

            GridMap.at(LoopCounter) = floor((atan2(YCoordinate, XCoordinate)+PI) * pow(10, PRECISION_DECIMAL_POINTS));
            }
    
        // We want the centre (starting) point to have a value of 0.
        GridMap.at(Centre) = 0;
        
        if(Action == "serialise"){
            std::cout<<TAB1<<"Serealising grid map angles at ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
            serialise();
            }
        else{
            std::cout<<TAB1<<"Grid map angles (into RAM) at ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
            }
        }
    else if(Action == "load"){
        std::cout<<TAB1<<"Loading angle change data at ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
        VectorSize = loadAngleChanges();
        if(VectorSize != GridPoints){std::cout<<TAB2<<"ERROR: Unexpected vector size ("<<VectorSize<<") vs. expected size("<<GridPoints<<")."<<std::endl;

        #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
            Logger.at(3).Invocations += 1;
            Logger.at(3).TotalExecutionTime += (clock() - LocalTimer);
        #endif        
        
        return FALSE;}
        }   
    else{
        std::cout<<TAB2<<"ERROR: Unrecognised initialisation action:"<<Action<<"."<<std::endl;

        #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
            Logger.at(3).Invocations += 1;
            Logger.at(3).TotalExecutionTime += (clock() - LocalTimer);
        #endif

        return FALSE;
        }

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(3).Invocations += 1;
        Logger.at(3).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return TRUE;
    }

/* PRIVATE
   We need to determine our initial direction of movement. We also need to ensure that the cumulative winding angle is 0 at the centre (Step 0).*/
int Grid::initialiseWalk(unsigned short int& GoingInDirection, unsigned short int& NowFacing, unsigned int& Position){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        clock_t LocalTimer = clock();
    #endif

    NowFacing = NORTH; 
    GoingInDirection = NORTH; 

    Walk.at(0) = (signed int) (0-GridMap.at(Position+1)); 
    
    FirstStep = NowFacing;
    GridMapTrace.at(Centre) = CENTRE_INITIAL_STATE;

    /* We need to ensure that the Direction Class static class variables which track rotation are reset.
       We can use the derived class chosen for Step 1.*/
    NewHeadings[GoingInDirection][NowFacing]->reset();

    Reporter.clear();
    Reporter.resize((WalkSteps*2));
    
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(7).Invocations += 1;
        Logger.at(7).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return TRUE;
    }

/* PRIVATE
    Load winding angle changes from file.
    Called from initialise()*/
signed int Grid::loadAngleChanges(){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        clock_t LocalTimer = clock();
    #endif

    long FileSize;
    size_t Index = 0;
    std::string FileName = "Grid_ST" + to_string(WalkSteps-1) + "CM" + to_string(COMPRESSION_FACTOR);

   while(TRUE){
      Index = FileName.find(".", Index);
      if(Index == std::string::npos) break;
      FileName.replace(Index, 1, "dot");
        } 

    FileName = FileName + ".Map";

    ifstream GridMapIn(FileName, ios::binary);

    if(!GridMapIn.good()){
        fatalError("Grid::loadAngleChanges. Attempt to load file " + FileName + " failed.");
        }
    else{        
        GridMapIn.seekg(0,ifstream::end);
        FileSize = GridMapIn.tellg();
        GridMapIn.seekg(0, ifstream::beg);
        GridMap.resize(FileSize / sizeof(unsigned int));
        GridMapIn.read((char*)&GridMap.at(0),FileSize);
        GridMapIn.close();
        }

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(5).Invocations += 1;
        Logger.at(5).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return FileSize / sizeof(signed int);
    }

/* PRIVATE
   At the start of each attempt to find a solution we must ensure that each grid position is set to zero apart from the centre (starting) position.*/
void Grid::reset(unsigned int& StepsCompleted){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        clock_t LocalTimer = clock();
    #endif

    // It is a great deal quicker to reset the grid positions visited during the previous solution / attempt than reset the entire grid each time.
    for(unsigned int LoopCounter = 0; LoopCounter < StepsCompleted; LoopCounter++){
        GridMapTrace.at(WalkPositionsVisited.at(LoopCounter)) = UNVISITED;
        }

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(8).Invocations += 1;
        Logger.at(8).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return;
    }

/* PRIVATE
   Writes all grid angles to file.
   Called from initialise() function when Action set to serialise.*/
void Grid::serialise(){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        clock_t LocalTimer = clock();
    #endif

    size_t Index = 0;
    std::string FileName = "Grid_ST" + to_string(WalkSteps-1) + "CM" + to_string(COMPRESSION_FACTOR);

   while(TRUE){
      Index = FileName.find(".", Index);
      if(Index == std::string::npos) break;
      FileName.replace(Index, 1, "dot");
        } 

    FileName = FileName + ".Map";

    ofstream GridMapOut(FileName, ios::out | ios::binary);
    GridMapOut.write((const char*)&GridMap.at(0), GridMap.size() * sizeof(unsigned int));
    GridMapOut.close();

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(4).Invocations += 1;
        Logger.at(4).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return;
    }

/* PRIVATE
   By creating an array of probability weighted direction outcomes at the outset, we improve subsequent efficiency during searcing for solutions.
   The scale factor lets us deal with non integer probabilities.*/
void Grid::setUpProbabilities(float ProbabilityRight, float ProbabilityLeft, unsigned short int ProbabilityScaleFactor){
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        clock_t LocalTimer = clock();
    #endif

    // To simplify the code and reduce typing later, we first create and calculate the value of a probality multiplier. 
    unsigned int ProbabilityMultiplier = pow((unsigned short int)10, (unsigned short int)ProbabilityScaleFactor);

    // Now we scale ProbabilityPoints according to the ProbabilityMultiplier. 
    ProbabilityPoints = ProbabilityPoints * ProbabilityMultiplier;

    // In case more decimal places have been used than are multiplied out by the scale factor, we use floor the left and right probabilities. 
    DirectionChoices.resize(floor(ProbabilityRight*ProbabilityMultiplier), GO_RIGHT);
    DirectionChoices.resize(floor((ProbabilityLeft + ProbabilityRight)*ProbabilityMultiplier), GO_LEFT);
    DirectionChoices.resize((ProbabilityPoints), GO_STRAIGHT_ON);
    
    std::cout<<TAB2<<"Probability Points: "<<ProbabilityPoints<<"."<<std::endl;

    #if ENABLE_VERBOSE_MODE()
        std::cout<<TAB3<<" DirectionChoices.size(): "<<DirectionChoices.size()<<"."<<std::endl;
        std::cout<<TAB3<<" Direction[0]: "<<DirectionChoices.at(0)<<". ";
        
        if(ProbabilityRight > 0 && ProbabilityRight < 100){
            // Last Right is before position ProbabilityPoints -1.
            std::cout<<" Direction["<<(ProbabilityRight*ProbabilityMultiplier)-1<<"]: "<<DirectionChoices.at((ProbabilityRight*ProbabilityMultiplier)-1)<<". ";
            }

        if(ProbabilityRight > 0 && ProbabilityLeft > 0){
            // First Left is not position 0.
            std::cout<<" Direction["<<(ProbabilityRight*ProbabilityMultiplier)<<"]: "<<DirectionChoices.at(ProbabilityRight*ProbabilityMultiplier)<<". ";
        }
        
        if(ProbabilityLeft > 0 && (ProbabilityRight + ProbabilityLeft) < 100){
            // Last Left is before position ProbabilityPoints -1.
            std::cout<<" Direction["<<((ProbabilityRight+ProbabilityLeft)*ProbabilityMultiplier)-1<<"]: "<<DirectionChoices.at(((ProbabilityRight+ProbabilityLeft)*ProbabilityMultiplier)-1)<<". ";
        }

        if((ProbabilityRight + ProbabilityLeft) > 0 && (ProbabilityRight + ProbabilityLeft) < 100){
            // First Straight On is not position 0.
            std::cout<<" Direction["<<(ProbabilityRight+ProbabilityLeft)*ProbabilityMultiplier<<"]: "<<DirectionChoices.at((ProbabilityRight+ProbabilityLeft)*ProbabilityMultiplier)<<". ";
            }

        std::cout<<" Direction["<<(ProbabilityPoints-1)<<"]: "<<DirectionChoices.at(ProbabilityPoints-1)<<"."<<std::endl;
    #endif

    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        Logger.at(2).Invocations += 1;
        Logger.at(2).TotalExecutionTime += (clock() - LocalTimer);
    #endif

    return;
    }