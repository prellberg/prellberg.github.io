#ifndef Grid_h
    #define Grid_h

    #include "Direction.h"
    #include "RandomWalkCommonHeader.h"

    class Grid{
        friend class Direction;
        
        public:
            Grid(unsigned int Steps, float Factor, float ProbabilityRight, float ProbabilityLeft, unsigned short int ProbabilityScaleFactor, unsigned short int ThreadNumber);
            std::vector<signed long> findWalk();
            int initialise(clock_t& Timer, std::string Action);

            // {START: ANALYSIS /UTILITY MEMBER VARIABLES AND FUNCTIONS}
            void analyseResults(); // Implemented in GridUtilities.cpp
            void displayExecutionTimes(); // Implemented in GridUtilities.cpp
            float getAverageLoopLength(); // Implemented in GridUtilities.cpp
            unsigned int getLoopsEncountered(); // Implemented in GridUtilities.cpp
            unsigned int getReturnsToCentre(); // Implemented in GridUtilities.cpp
            unsigned short int getThread(); // Implemented in GridUtilities.cpp
            // {END: ANALYSIS MEMBER VARIABLES AND FUNCTIONS}

            #if ENABLE_ANALYSIS_MODE()
                unsigned long GoStraightOn = 0;
                unsigned long OtherDirectionChange = 0;
                unsigned long TurnLeft = 0;
                unsigned long TurnRight = 0;
            #endif
        
        private:
            Direction* NewHeadings [4][4];
            DirectionError*  RetracingSteps  = new DirectionError(this, 4,0);
            East*  FacingEast  = new East(this, EAST,2);
            North* FacingNorth = new North(this, NORTH,0);
            South* FacingSouth = new South(this, SOUTH,0);
            West*  FacingWest  = new West(this, WEST,2);

            float GridCompression;
            signed long BoundaryTest;
            unsigned int CentreX;
            unsigned int CentreY;
            unsigned int Centre;
            unsigned int GridPoints;
            unsigned int Length;
            unsigned int LoopsEncountered = 0;
            unsigned int PiAsUnsignedInt = floor(PI*pow(10,PRECISION_DECIMAL_POINTS));
            unsigned int ProbabilityPoints = 100;
            unsigned int ReturnsToCentre = 0;
            unsigned int WalkSteps;
            unsigned long AggregateLoopLength = 0;
            unsigned short int FirstStep;
            unsigned short int FunctionsActuallyLogged = 0;
            unsigned short int Thread;
            std::vector<Log> Logger;
            std::vector<unsigned int> GridMap;
            std::vector<unsigned int> WalkPositionsVisited;
            std::vector<unsigned short int> DirectionChoices;
            std::vector<unsigned short int> GridMapTrace;
            std::vector<signed long> Walk;
            std::vector<std::string>Reporter;
            
            int initialiseWalk(unsigned short int& GoingInDirection, unsigned short int& NowFacing, unsigned int& Position);
            signed int loadAngleChanges();
            void initialiseLogger();
            void reset(unsigned int& CompletedSteps);
            void serialise();
            void setUpProbabilities(float ProbabilityRight, float ProbabilityLeft, unsigned short int ProbabilityScaleFactor);

            // {START: ANALYSIS MEMBER VARIABLES AND FUNCTIONS}
            // These are used and implemented in GridUtilities.cpp
            signed int MaxX = 0;
            signed int MaxY = 0;
            signed int MinY = 0;
            signed int MinX = 0;
            unsigned int TestPosition;
            std::vector<unsigned short int> TestDirections;
        
            std::string getDirectionAsText(unsigned short int Direction);
            void trackGridUse(unsigned int Step, signed int CurrentX, signed int CurrentY);
            void updateCoordinates(signed int& CurrentX, signed int& CurrentY, unsigned int& Position);
            // {END: ANALYSIS MEMBER VARIABLES AND FUNCTIONS}
        };
#endif