#include "Grid.h"

/* PUBLIC
   Function called during design.
   The function is called when #define ENABLE_ANALYSIS_MODE() is set to TRUE.*/
void Grid::analyseResults(){
    std::cout<<std::endl<<"VERSION "<<VERSION<<" ANALYSIS."<<std::endl;
    std::cout<<TAB1<<"A half axis is "<<(int)(Length-1)/2<<" units."<<std::endl;
    std::cout<<TAB1<<"The minimum value of X reached was  "<<MinX<<"."<<std::endl;
    std::cout<<TAB1<<"The maximum value of X reached was  "<<MaxX<<"."<<std::endl;
    std::cout<<TAB1<<"The minimum value of Y reached was  "<<MinY<<"."<<std::endl;
    std::cout<<TAB1<<"The maximum value of Y reached was  "<<MaxY<<"."<<std::endl;
    return;
    }

/* PUBLIC
   Displays the name of each tracked function, the number of times it was invoked and the total execution time..
   The function is called when #define ENABLE_LOG_FUNCTION_EXECUTION_TIME() is set to TRUE
   and ENABLE_MULTIPLE_THREADS() is set to FALSE.*/
void Grid::displayExecutionTimes(){
    std::cout<<std::endl<<"VERSION "<<VERSION<<" (TRACKED) FUNCTION EXECUTION TIMES."<<std::endl;

    for(short int Count = 0; Count < Logger.size(); Count++){
        std::cout<<TAB1<<Logger.at(Count).RelativeIndentation<<Logger.at(Count).ID<<": "<<Logger.at(Count).FunctionName<<" was invoked "<<Logger.at(Count).Invocations;
            std::cout<<" times. The total execution time was "<<(float)Logger.at(Count).TotalExecutionTime/CLOCKS_PER_SEC<<" seconds."<<std::endl;
        }
   
    std::cout<<std::endl<<TAB1<<"Note 1: The logging function imposes a huge overhead and when enabled consumes the vast majority of programme execution time."<<std::endl;
    std::cout<<TAB1<<"Note 2: 50% of the time in findWalk is oddly unaccounted for."<<std::endl;
    std::cout<<TAB1<<"Note 3: The primary value of the statistics is therefore looking at relative execution times across functions."<<std::endl;

    return;
    }

/* PRIVATE
   Converts Direction short int representation to text for reporting progress.
   The function is called when #define ENABLE_VERBOSE_MODE() is set to TRUE.*/
std::string Grid::getDirectionAsText(unsigned short int Direction){
    if (Direction == 1) return "East";
    else if (Direction == 2) return "South";
    else if (Direction == 3) return "West";
    else if (Direction == 0) return "North";
    else{ fatalError("Grid::getDirectionAsText. Direction code " + std::to_string(Direction) + " provided."); return "FATAL ERROR"; }
    }

/* PUBLIC
   Used on completion of the search when reporting on the results.*/
float Grid::getAverageLoopLength(){
    return (float) AggregateLoopLength / LoopsEncountered;
    }

/* PUBLIC
   Used on completion of the search when reporting on the results.*/
unsigned int Grid::getLoopsEncountered(){
    return LoopsEncountered;
    }

/* PUBLIC
   Used on completion of the search when reporting on the results.*/
unsigned int Grid::getReturnsToCentre(){
    return ReturnsToCentre;
    }

/* PUBLIC
    Returns the thread number of the Grid */
unsigned short int Grid::getThread(){
    return Thread;
    }  
    
/* PRIVATE
   Sets up the Logger with the function name of all functions that are being logged.
   In other words it does not log all execution time, but only that spent in functions of interest.
   1. In order to reduce the overhead of the logging "function" itself, all chosen functions do their own logging.
   2. Discipline is required to ensure that a function updates the correct Logger entry;
   2.1. A copy and paste without subsequent update of the code and a new entry in this function will result in;
   2.1.1 The execution time for the new function not being logged and,
   2.2.2 The execution time for the new function will be undetectably added to that for the copied function.
   3. The logging function imposes a significant overhead and when enabled consumes a significant majority of the time executing the programme.
   3.1 50% of the time in findWalk is unaccounted for.
   4. Where both a function and the function it is called from are logged, both logs will include the execution time.
   4.1 Use the RelativeIndentation attribute to indicate functions called from another logged function and thus dupliacted execution times.
   The function is called when #define ENABLE_LOG_FUNCTION_EXECUTION_TIME() is set to TRUE.
   This function will be diasabled if ENABLE_MULTIPLE_THREADS() set to TRUE as the results and then potentially invalid and no more informative.*/
void Grid::initialiseLogger(){
    // No need to test ENABLE_LOG_FUNCTION_EXECUTION_TIME()
    clock_t LocalTimer = clock();

    Logger.resize(++FunctionsActuallyLogged); Logger.at(0).FunctionName = "Grid() constructor"; Logger.at(0).ID = "1";
    Logger.resize(++FunctionsActuallyLogged); Logger.at(1).FunctionName = "initialiseLogger"; Logger.at(1).ID = "1.2"; Logger.at(1).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(2).FunctionName = "setUpProbabilities"; Logger.at(2).ID = "1.1"; Logger.at(2).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(3).FunctionName = "initialise"; Logger.at(3).ID = "2";
    Logger.resize(++FunctionsActuallyLogged); Logger.at(4).FunctionName = "serialise"; Logger.at(4).ID = "2.1"; Logger.at(4).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(5).FunctionName = "loadAngleChanges"; Logger.at(5).ID = "2.2"; Logger.at(5).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(6).FunctionName = "findWalk"; Logger.at(6).ID = "3";   
    Logger.resize(++FunctionsActuallyLogged); Logger.at(7).FunctionName = "initialiseWalk"; Logger.at(7).ID = "3.1"; Logger.at(7).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(8).FunctionName = "reset"; Logger.at(8).ID = "3.2"; Logger.at(8).RelativeIndentation = TAB1;
    Logger.resize(++FunctionsActuallyLogged); Logger.at(9).FunctionName = "Direction::takeOneStep"; Logger.at(9).ID = "3.3"; Logger.at(9).RelativeIndentation = TAB1;
    
    Logger.at(1).Invocations += 1;
    Logger.at(1).TotalExecutionTime += ((clock() - LocalTimer));

    return;
    }

/* PRIVATE
   The function tracks how far the set of solutions spreads out over the grid.
   The information obtained is used to set the COMPRESSION_FACTOR to allow best performance and scalability for a given number of steps.
   The function is called when #define ENABLE_ANALYSIS_MODE() is set to TRUE.*/
void Grid::trackGridUse(unsigned int Step, signed int CurrentX, signed int CurrentY){
    if(CurrentY < MinY) MinY = CurrentY;
    else if(CurrentY > MaxY) MaxY = CurrentY;
    else if(CurrentX < MinX) MinX = CurrentX;
    else if(CurrentX > MaxX) MaxX = CurrentX;

    #if ENABLE_VERBOSE_MODE()
        std::cout<<TAB3<<"MinX:"<<MinX<<", MaxX:"<<MaxX<<", MinY:"<<MinY<<", MaxY:"<<MaxY<<"."<<std::endl;
    #endif

    return;
    }

/* PRIVATE
   The function converts the grid position expressed as a vector position to one in coordinates centred in the middle of the grid.
   The function is called when either #define ENABLE_VERBOSE_MODE() or #define ENABLE_ANALYSIS_MODE() is set to TRUE.*/
void Grid::updateCoordinates(signed int& CurrentX, signed int& CurrentY, unsigned int& Position){
    CurrentY = (Position % Length) - CentreY;
    CurrentX = ((Position - CurrentY) / Length) - CentreX;

    return;
    }