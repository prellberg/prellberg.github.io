Random Walk Version [10.0.0]
Nathalie Richards
Up to date as of 17th August, 2020

1 INTRODUCTION
2 COMMAND LINE INSTRUCTIONS
3 SUMMARY OF CLASSES
4 SUMMARY OF OTHER USEFUL FILES
5 PAL REPORT (PROBLEMS, ANOMALIES AND LIMITATIONS)
6 UNINTEGRATED FUNCTIONALITY

1 INTRODUCTION

1.1 Program enables the determination of Winding Angles for Random Walks with left and right mirror probabilities specified in the command line.
1.2 A lot of functionality can be enabled/disabled via RandomWalkCommonHeader.h which is reasonably well commented
1.3 Due to thread capability program must be compiled with the following command: g++ -fopenmp *.cpp -o run -std=c++11

2 COMMAND LINE INSTRUCTIONS

2.1 Six command line parameters are required. They can be supplied in any order.
2.1.1 Parameter names are case sensitive.
2.1.2 Parameters must be specified as ParemeterName=ParameterValue. No spaces are allowed around the '=' sign.
2.1.3 Parameters must be separated by space.
2.2 Probability Right (PRight) and ProbabilityLeft (PLeft) can be specified as decimal numbers or as integers as a percentage of 100.
2.3 The ProbabilityScaleFactor (PScaleFactor) must be set to at least the greater of the number of decimal points used for PRight and PLeft.
2.4 Steps cannot exceed MAXIMUM_STEPS. MAXIMUM_STEPS is defined in RandomWalkCommonHeader.h. 
2.5 The product of Steps*Solutions must not exceed MAXIMUM_SOLUTION_STEPS. MAXIMUM_SOLUTION_STEPS is defined in RandomWalkCommonHeader.h.
2.6 Using a new value of Steps may require a change to COMPRESSION_FACTOR in RandomWalkCommonHeader.h followed by a recompile. See RandomWalkCommonHeader.h for guidance.
2.6.1 COMPRESSION_FACTOR is the maximum proportion of grid to be reached with any run
2.7 Action may take the value 'serialise', RAM or 'load'.
2.7.1 Running the programme with Action=serialise will result in the creation of file Grid.Map.
2.7.2 Running the programme with inconsistent Steps and Grid.Map file will result in an error.
2.7.3 Running the programme with Action=RAM will result not result in or require the creation of file Grid.Map
2.7.4 Running the programme with Action=load and no Grid.Map file present is an uncontrolled condition and the programme will crash.
2.7.5 Action=serialise, Action=RAM and Action=load give the same results. Programme execution with Action=load will be quicker.
2.8 Additional functionality is enabled / disabled by parameters specified in RandomWalkCommonHeader.h. Enabling / disabling functionality in this way requires recompilation.
2.9 Example: ./run Solutions=1000 PRight=33.333 PScaleFactor=3 Steps=2000 Action=load PLeft=33.333.


3 SUMMARY OF CLASSES 
In order of flow of control;

3.1 Grid
3.2 Direction
3.3 Analytics 

4 SUMMARY OF OTHER USEFUL FILES 
In suggested order of familiarisation;

4.1 RandomWalk.cpp
4.2 RandomWalkCommonHeader.h
4.3 RandomWalkUtilities.cpp
4.4 GridUtilities.cpp


PAL REPORT (PROBLEMS, ANOMALIES AND LIMITATIONS)

5.1 PROBLEMS
5.1.1 Uncontrolled programme termination if Action is set to load when no data files are available.

5.2 ANOMALIES
5.2.1 RandomWalkCommonHeader.h #defines guards which determine conditional compilation and run-independent global constants. It also includes the #defines LOWEST_BIN, HIGHEST_BIN and NUMBER_BINS. These #defines represent run-specific global constants and should be passed in on the command line.
5.2.2 The timings reported in our put messages are correct when executing with a single thread but seem much too high with ENABLE_MULTIPLE_THREADS() set to TRUE.

5.3 LIMITATIONS
5.3.1 At present, the user must use the guidelines in RandomWalkCommonHeader.h to determine and set the Compression Factor, followed by a recompilation. It would be better if a #define MAXIMUM_AVAILABLE_RAM_PER_THREAD was added and the programme automatically calculated the Compression Factor.
5.3.2 At present, the user must set the MAXIMUM_STEPS and MAXIMUM_SOLUTION_STEPS in RandomWalkCommonHeader. It would be better if the programme automatically determined these limits using the #define MAXIMUM_AVAILABLE_RAM_PER_THREAD discussed above.
5.3.3 The current implementation uses a Grid Map of pre-calculated winding angles and tracks the accumulating winding angle at each step in the walk. For any given step, it therefore takes the current cumulative winding angle and adds to it the difference between the respective winding angles for the current and previous grid positions. For cumulative winding angles less than 360 degrees, the result is exactly the same as the precalculated winding angle at the current position itself. As such it is wasteful of processor resources. However, it has the advantages of inherently dealing with 1) direction of rotation and 2) cumulative angles that exceed 360 degrees. A more satisfying and more processor efficient solution was previously implemented; namely that Grid Map was replaced by four grids representing the change in winding angle associated with moving to a particular grid point from each of its four neighbours. However, while quicker, the extra RAM required meant that the solution was not viable for Steps greater than 1,000 on the low spec’d Google Chromebook used for development. Note that a third solution was implemented and is discussed in the following section. 

6. UNINTEGRATED FUNCTIONALITY
In order to remove defects and minimise the potential for regression testing errors, a number of completed and working functional changes have been removed from the code. This has the advantage of ensuring that the submitted code is that which is responsible for all data generation activities. However, it does also mean that some significant areas of effort in producing a more complete program of greater utility for future work are not present in the submitted code. These are;

6.1 The current solution uses a vector rather than an array and, after creation of Grid Map of winding angles, only makes reference to X and Y coordinates when producing output in Verbose mode.  This approach is reliable but relatively slow as it requires conversion of a vector offset to a pair of coordinates for each Solution * Step.

The unintegrated working alternative uses Direction class static member variables and polymorphism such that the subclasses of Direction increment / decrement as appropriate the relevant coordinate during the takeOneStep() function. This is considerably quicker and provides the basis for the next unintegrated piece of functionality.
6.2 As noted in the section on LIMITATIONS, the development machine used for this project had limited resources. An alternative way to track winding angles was implemented. This approach tracked the cumulative number and direction of complete transits across the initial half axis (this was before the appreciation that Step 1 was always North). All that is necessary for the final step is to add the partial winding angle to the count of complete transits * 360 degrees. This approach is marginally more processor intensive and therefore was not taken forward for the mainframe data collection activity, but considerably increases the size of Steps that a development machine can handle.

6.3 A mode was introduced to capture and all random numbers generated and save these to file. The file name included the parameters of the run and the aggregate of Winding Angle * Solution, summed over all solutions. A further mode was introduced to replay the random numbers from the stored file and check the results against the totals encoded in the file name.  Not only does this provide useful enable regression testing (it was only implemented in single thread mode), it also allows for data exchange between different solutions. Future students taking forward this work could exchange random number files with their supervisor and rapidly, and quantitatively, determine whether both programs were giving the same results. 

