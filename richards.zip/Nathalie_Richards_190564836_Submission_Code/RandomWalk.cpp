#include "Analytics.h"
#include "Grid.h"
#include "RandomWalkUtilities.h"

#include <cstdlib>
#include <ctime>

int launchThreads(unsigned int& Steps, unsigned int& SolutionsWanted, float Compression, float ProbabilityRight,
    float ProbabilityLeft, unsigned short int ProbabilityScaleFactor, clock_t& Timer, std::string& Action,
    std::string& PRightAsText, std::string& PLeftAsText , std::vector<Analytics*> &ProgramAnalytics);

int threadMain(unsigned int& Steps, unsigned int& SolutionShare, float Compression, float ProbabilityRight,
    float ProbabilityLeft, unsigned short int ProbabilityScaleFactor, clock_t& Timer, std::string& Action,
    unsigned short int ThisThread, std::string& PRightAsText, std::string& PLeftAsText, Analytics* ProgramAnalytics);

int main(int argC, char** argV){
    clock_t Timer = clock();
    // Some information is useful even during VERBOSE_MODE
    std::cout<<std::endl<<"VERSION "<<VERSION<<" BEGINNING AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;

    float ProbabilityLeft;
    float ProbabilityRight;
    int CallSuccessful;
    std::string Action;
    std::string PLeftAsText;
    std::string PRightAsText;
    unsigned int SolutionsWanted;
    unsigned int Steps;
    /* 100 is multiplied by 10 raised to the power of the Probability Scale Factor to give the total Probability Points.
       This enables support for fractional probabilities for straight on, left and right.
       For example if we had straight on = 33.1, right = 33.5 and left = 33.4, we could set the scale factor to 1.
       This would give 1,000 probability points: 331 (straight on), 335 (right) and 334 (left) = 1,000*/
    unsigned short int ProbabilityScaleFactor;
 
    // Some information is useful even during VERBOSE_MODE
    CallSuccessful = processCommandLine(argC, argV, *&Steps, *&SolutionsWanted, *&ProbabilityRight, *&ProbabilityLeft,
        *&ProbabilityScaleFactor, *&Action, *&PLeftAsText, *&PRightAsText);

    if(CallSuccessful == FALSE){
        std::cout<<TAB1<<"Problem with processing command line. Quitting..."<<std::endl;
        displayCommandLineInstructions();
        return -1;
        }
   
    // Seed random number generator for use in initialisation of xoshirostarstar implementation.
    srand(time(0));

    // Initialise custom xoshiro256** random number generator
    xoshiro256ss_init();
   
    // Initialise class for calculating Analytics
    std::vector<Analytics*> ProgramAnalytics;
    ProgramAnalytics.resize(omp_get_max_threads());
    
    // Ensure each thread has access to Analytics class, class uses the number of bins and bin range defined in RandomWalkCommonHeader.h
    for(unsigned short int i=0; i<omp_get_max_threads(); i++){
        ProgramAnalytics.at(i)=new Analytics(LOWEST_BIN, HIGHEST_BIN, NUMBER_BINS);
        }
        #if ENABLE_MULTIPLE_THREADS()
            launchThreads(Steps, SolutionsWanted, COMPRESSION_FACTOR, ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor, Timer, Action, PRightAsText, PLeftAsText, ProgramAnalytics); 
        #else
            threadMain(Steps,SolutionsWanted, COMPRESSION_FACTOR, ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor, Timer, Action, 0, PRightAsText, PLeftAsText,  ProgramAnalytics.at(0));
        #endif      

   return NORMAL_TERMINATION;
   }
   
// Intermediate function to execute main() across multiple threads.
int launchThreads(unsigned int& Steps, unsigned int& SolutionsWanted, float Compression, float ProbabilityRight,
   float ProbabilityLeft, unsigned short int ProbabilityScaleFactor, clock_t& Timer, std::string& Action,
   std::string& PRightAsText, std::string& PLeftAsText,  std::vector<Analytics*> &ProgramAnalytics){
   unsigned int FirstSolution; 
   unsigned int SolutionShare;
   unsigned short int ThisThread;
   unsigned short int Threads;

   #pragma omp parallel default (shared) private(ThisThread, Threads, SolutionShare, FirstSolution)
   {
      ThisThread = omp_get_thread_num();
      Threads = omp_get_num_threads();
      SolutionShare = SolutionsWanted / Threads;
      FirstSolution = ThisThread * SolutionShare;
      if(ThisThread == Threads-1){ SolutionShare = SolutionsWanted - FirstSolution; }

      threadMain(Steps, SolutionShare, Compression, ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor,
         Timer, Action, ThisThread, PRightAsText, PLeftAsText,  ProgramAnalytics.at(ThisThread));
   }

   return NORMAL_TERMINATION;
   } 
    
// Thread code split out of main
int threadMain(unsigned int& Steps, unsigned int& SolutionShare, float Compression, float ProbabilityRight,
   float ProbabilityLeft, unsigned short int ProbabilityScaleFactor, clock_t& Timer, std::string& Action,
   unsigned short int ThisThread, std::string& PRightAsText, std::string& PLeftAsText ,Analytics* ProgramAnalytics){
   int CallSuccessful;
   
    // Create and resize grid and its associated vectors of winding angle differences.
    // Note we intentionally pass Steps rather than Steps + 1.
    Grid SolutionGrid(Steps, COMPRESSION_FACTOR, ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor, ThisThread);
   
    // Some information is useful even during VERBOSE_MODE.
    std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" INITIALISING GRID AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
    CallSuccessful = SolutionGrid.initialise(Timer, Action);
    
    if(CallSuccessful == FALSE) {std::cout<<TAB1<<"Problem with initialisation. Quitting..."<<std::endl; return -1;}

    unsigned int Solution = 0;
    unsigned int SolutionsFound;
    unsigned int SolutionsWanted = SolutionShare;
     
    #if ENABLE_SAVE_WINDING_ANGLES() || ENABLE_OUTPUT_WINDING_ANGLES()
        // Create a vector to hold Winding angles.
        std::vector<float> WindingAngles(SolutionsWanted);
    #endif

    /* Create vector of vectors to hold all solutions.
    Float because we shall be recording winding angles. With more available memory would use doubles.
    Add 1 to capture the centre position.
    Since no need for paths once we have the winding angles, there is an option to discard them as we are going along.*/
    #if ENABLE_SAVE_SUCCESSFUL_PATHS()
        std::vector<std::vector<signed long>> WalkCollection(SolutionsWanted, vector<signed long>(Steps+1));
    #else
        std::vector<std::vector<signed long>> WalkCollection(1, vector<signed long>(Steps+1));
    #endif

    // Some information is useful even during VERBOSE_MODE.
    std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" LOOKING FOR SOLUTIONS AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
    // Repeatedly call the grid findWalk function until the require number of solutions have been found.
    for(SolutionsFound = 0; SolutionsFound < SolutionsWanted; SolutionsFound++){
        #if ENABLE_VERBOSE_MODE()
            std::cout<<std::endl<<std::endl<<TAB1<<"Looking for Solution "<<SolutionsFound+1<<"."<<std::endl;
        #endif

        #if ENABLE_SAVE_SUCCESSFUL_PATHS()
            Solution = SolutionsFound;
        #endif

        WalkCollection.at(Solution) = SolutionGrid.findWalk();
         
        #if ENABLE_SAVE_WINDING_ANGLES()
            WindingAngles.at(SolutionsFound) = (WalkCollection.at(Solution).at(Steps) / pow(10,PRECISION_DECIMAL_POINTS)) * (180 / PI);
        #endif
         
        #if ENABLE_OUTPUT_ANALYTICS()
            ProgramAnalytics->push((WalkCollection.at(Solution).at(Steps) / pow(10,PRECISION_DECIMAL_POINTS)) * (180 / PI)); 
        #endif

        #if ENABLE_OUTPUT_WINDING_ANGLES()
            std::cout<<std::endl<<"Solution: "<<SolutionsFound+1<<", Winding angle: "<<WindingAngles.at(SolutionsFound)<<"."<<std::endl;
        #endif
        }

    // Some information is useful even during VERBOSE_MODE.
    std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" COMPLETED AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
    std::cout<<std::endl<<TAB1<<"Solutions found: "<<SolutionsFound<<"."<<std::endl;
    std::cout<<std::endl<<TAB1<<"Returned to the centre: "<<(unsigned int) SolutionGrid.getReturnsToCentre()<<" times."<<std::endl;
    std::cout<<std::endl<<TAB1<<"Loops encountered: "<<(unsigned int) SolutionGrid.getLoopsEncountered()<<"."<<std::endl;
    std::cout<<std::endl<<TAB1<<"Average loop length: "<<(float) SolutionGrid.getAverageLoopLength()<<"."<<std::endl;
   
    #if ENABLE_ANALYSIS_MODE()
        /* Provide information about grid use coverage.
           The results can be used to determine whether we get away with a smaller grid.*/
        SolutionGrid.analyseResults();

        /* Investigation of behavioural variance with Professor's code
           Investigate random generation of changes of direction.*/
        std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" VARIANCE ANALYSIS."<<std::endl;
        unsigned long TotalDirectionEvents = SolutionGrid.GoStraightOn+SolutionGrid.TurnLeft+SolutionGrid.TurnRight+SolutionGrid.OtherDirectionChange;
        std::cout<<"Total Direction Events: "<<TotalDirectionEvents<<"."<<std::endl;
        std::cout<<TAB1<<"Turn Left: "<<SolutionGrid.TurnLeft<<" ("<<(float)(100*SolutionGrid.TurnLeft)/TotalDirectionEvents<<"%) ."<<std::endl;
        std::cout<<TAB1<<"StraightOn: "<<SolutionGrid.GoStraightOn<<" ("<<(float)(100*SolutionGrid.GoStraightOn)/TotalDirectionEvents<<"%) ."<<std::endl;
        std::cout<<TAB1<<"Turn Right: "<<SolutionGrid.TurnRight<<" ("<<(float)(100*SolutionGrid.TurnRight)/TotalDirectionEvents<<"%) ."<<std::endl;
        std::cout<<TAB1<<"Other Direction Change: "<<SolutionGrid.OtherDirectionChange<<" ("<<(float)(100*SolutionGrid.OtherDirectionChange)/TotalDirectionEvents<<"%) ."<<std::endl;
   #endif

   #if ENABLE_SAVE_WINDING_ANGLES() 
        std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" SAVING "<<WindingAngles.size()<<" WINDING ANGLES AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;
        std::string WindingAngleResults = getWindingAngleFileName(Steps, SolutionsWanted, PRightAsText, PLeftAsText, ThisThread);

        writeWindingAnglesToStream(WindingAngleResults, WindingAngles);
    #endif
        
        
    #if ENABLE_OUTPUT_ANALYTICS()
        // Some information is useful even during VERBOSE_MODE.
        std::cout<<std::endl<<"VERSION "<<VERSION<<" THREAD: "<<SolutionGrid.getThread()<<" SAVING HISTOGRAM AT ("<<(float)(clock()-Timer)/CLOCKS_PER_SEC<<") seconds."<<std::endl;

        std::string HistogramResults = getHistogramFileName(Steps, SolutionsWanted, PRightAsText, PLeftAsText, ThisThread);
        std::string AnalyticResults = getAnalyticFileName(Steps, SolutionsWanted, PRightAsText, PLeftAsText, ThisThread);

        ProgramAnalytics->writeHistogramToStream(HistogramResults);
        ProgramAnalytics->outputResults(AnalyticResults, Steps);
            
	    // Some information is useful even during VERBOSE_MODE.
        std::cout<<std::endl<<"Analytics:"<<" THREAD: "<<SolutionGrid.getThread()<<std::endl;
        std::cout<<std::endl<<TAB1<<"Mean Winding Angle: "<<ProgramAnalytics->calculateMean()<<std::endl;
        std::cout<<std::endl<<TAB1<<"Winding Angle Variance: "<<ProgramAnalytics->calculateVariance()<<std::endl;
        std::cout<<std::endl<<TAB1<<"Winding Angle Variance in Radians: "<<ProgramAnalytics->calculateRadianVariance()<<std::endl;
        std::cout<<std::endl<<TAB1<<"Winding Angle Kurtosis: "<<(ProgramAnalytics->calculateKurtosis()+3)<<std::endl<<std::endl;
    #endif
        
    #if ENABLE_LOG_FUNCTION_EXECUTION_TIME() && !ENABLE_MULTIPLE_THREADS()
        SolutionGrid.displayExecutionTimes();
    #endif   

    return NORMAL_TERMINATION;
    }