#ifndef RandomWalkCommonHeader_h
    #define RandomWalkCommonHeader_h

    #define CENTRE_INITIAL_STATE 0
    #define CLOCKWISE 0
    #define COUNTER_CLOCKWISE 1
    #define COMPRESSION_FACTOR 1 // Suggested values 1.0 for up to 10,000 steps, 0.1 for 100,000 steps and 0.05 for 1 million steps
    #define EAST 1
    #define ENABLE_ANALYSIS_MODE() FALSE // It shows how much of Grid.Map has been used. Unused Grid.Map means COMPRESSION_FACTOR may be reduce. Aim for a "buffer" of 1. Introduces a time overhead!
    #define ENABLE_MULTIPLE_THREADS() FALSE // Splits solutions between available cores, each using its own grid map and creating instances of analysis class
    #define ENABLE_LOG_FUNCTION_EXECUTION_TIME() FALSE //:: This can be used to track the relative execution time of functions. See GridUtilities.cpp for more information. Introduces an overhead!
    #define ENABLE_OUTPUT_ANALYTICS() TRUE //This writes winding angles to analytics class and reports mean and std dev to terminal
    #define ENABLE_OUTPUT_WINDING_ANGLES() FALSE // Enabling this functionality writes WindingAngles to the display. winding angles are not currently saved.
    #define ENABLE_SAVE_SUCCESSFUL_PATHS() FALSE // We do not need the paths once we have the winding angles. A value of FALSE therefore saves memory.
    #define ENABLE_SAVE_WINDING_ANGLES() FALSE // Enabling this function saves winding angle to csv file name as specified in RandomWalk.cpp
    #define ENABLE_VERBOSE_MODE() FALSE // Generates considerably more output. It is advisable to only use this with small Steps and Solutions to avoid swamoing the display with output.   
    #define FALSE false
    #define FIRST_VISIT 1
    #define GO_LEFT 3
    #define GO_RIGHT 1
    #define GO_STRAIGHT_ON 0
    #define MAXIMUM_SOLUTION_STEPS 1000000000000
    #define MAXIMUM_STEPS 1000000
    #define NORMAL_TERMINATION 1
    #define NORTH 0
    #define PI 3.141592654
    /* Note that we have to give up one decimal point of precision due to resource constraints on the development machine.
       In other words we can multiple radian values between 0 and 2pi by 10 ^ 8 and do signed arrithmatic without causing overflow errors.
       This is at the cost of precision. The cumulative effects should be calculated to see if they are significant.
       On a computer with greater memory we would have the option of using larger data types. */
    #define PRECISION_DECIMAL_POINTS 8
    #define SOUTH 2
    #define TAB1 "  "
    #define TAB2 "      "
    #define TAB3 "          "
    #define TRUE true
    #define UNVISITED 7
    #define VERSION "10.0.0 Final Project Code"
    #define VISITED_TWICE 6
    #define VERY_BIG 100000000
    #define WEST 3
    
    /* Below is the information requried for the statistic element of the program,
       The lower and upper bins are defined in winding angles and should be altered depending on the ratio of Left to Right.
       These #defines should be removed from RandonWalkCommonHeader and passed on the Command Line.*/
    #define LOWEST_BIN -1097.5
    #define HIGHEST_BIN 1097.5
    #define NUMBER_BINS 439

    #include <math.h>
    #include <time.h>
    #include <omp.h> 
    
    #include <cstdlib>
    #include <fstream>
    #include <iostream>
    #include <sstream>
    #include <string>
    #include <vector>

    using namespace std;

    typedef struct Log {
    clock_t TotalExecutionTime = 0;
    long Invocations = 0;
    std::string ID;
    std::string FunctionName;
    std::string RelativeIndentation = "";
    } Log;

    unsigned int nextRandomDirectionChange(unsigned int Range);
    void xoshiro256ss_init();

    inline void fatalError(const std::string& Message){
	    std::cout<<"FATAL ERROR: "<<Message<<" Exiting..."<<std::endl;
	    exit(EXIT_FAILURE);
        }
#endif