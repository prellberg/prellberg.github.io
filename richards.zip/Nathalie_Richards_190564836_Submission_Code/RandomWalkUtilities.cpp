#include "RandomWalkUtilities.h"

/* Outputs key information from RandomWalkCommonHeader.h, the command line and derived variables once the command line has been correctly validated and processed.
    Called from processCommandLine. */
void displayProgrammeParameters(unsigned int& Steps, unsigned int& SolutionsWanted, float& ProbabilityRight, float& ProbabilityLeft, unsigned short int& ProbabilityScaleFactor, std::string& Action){
std::cout<<TAB1<<"[From RandomWalkCommonHeader.h]"<<std::endl;
    std::cout<<TAB2<<"Compression Factor: "<<COMPRESSION_FACTOR<<"."<<std::endl;
    std::cout<<TAB3<<"Note: Suggested values 1.0 for upto 1,000 steps, 0.51 for 10,000 steps, 0.015 for 100,000 steps and 0.0053 for 1 million steps."<<std::endl;
    if(ENABLE_ANALYSIS_MODE()) std::cout<<TAB2<<"Analysis Mode: Enabled."<<std::endl; else std::cout<<TAB2<<"Analysis Mode: Disabled."<<std::endl;
    if(ENABLE_LOG_FUNCTION_EXECUTION_TIME()) std::cout<<TAB2<<"Log Function Execution Time: Enabled."<<std::endl; else std::cout<<TAB2<<"Log Function Execution Time: Disabled."<<std::endl;
    if(ENABLE_MULTIPLE_THREADS()) std::cout<<TAB2<<"Multiple Threads: Enabled."<<std::endl; else std::cout<<TAB2<<"Multiple Threads: Disabled."<<std::endl;

    if(ENABLE_LOG_FUNCTION_EXECUTION_TIME() && ENABLE_MULTIPLE_THREADS()){
        std::cout<<TAB3<<"Both Log Function Execution Time and Multiple Threads enabled. Disabling Log Function Execution Time..."<<std::endl;
        }

    if(ENABLE_OUTPUT_ANALYTICS()) std::cout<<TAB2<<"Output Analytics: Enabled."<<std::endl; else std::cout<<TAB2<<"Output Analytics: Disabled."<<std::endl;
    if(ENABLE_OUTPUT_WINDING_ANGLES()) std::cout<<TAB2<<"Output Winding Angles: Enabled."<<std::endl; else std::cout<<TAB2<<"Output Winding Angles: Disabled."<<std::endl;
    if(ENABLE_SAVE_SUCCESSFUL_PATHS()) std::cout<<TAB2<<"Perform Save Successful Paths: Enabled."<<std::endl; else std::cout<<TAB2<<"Perform Save Successful Paths: Disabled."<<std::endl;
    if(ENABLE_SAVE_WINDING_ANGLES()) std::cout<<TAB2<<"Perform Save Winding Angles: Enabled."<<std::endl; else std::cout<<TAB2<<"Perform Save Winding Angles: Disabled."<<std::endl;
    if(ENABLE_VERBOSE_MODE()) std::cout<<TAB2<<"Verbose Mode: Enabled."<<std::endl; else std::cout<<TAB2<<"Verbose Mode: Disabled."<<std::endl;
    std::cout<<TAB1<<"[From the command line]"<<std::endl;
    std::cout<<TAB2<<"Action on initialisation: "<<Action<<"."<<std::endl;
    std::cout<<TAB2<<"Steps: "<<Steps<<", Solutions Wanted: "<<SolutionsWanted<<"."<<std::endl;
    std::cout<<TAB2<<"Probability Right: "<<ProbabilityRight<<", Probability Left: "<<ProbabilityLeft<<", Probability Scale Factor: "<<ProbabilityScaleFactor<<"."<<std::endl;
    std::cout<<TAB1<<"[Important derived variables]"<<std::endl;

    return;
    }
   
/* Outputs instructions on how to run the programme.
    It is called from main() if the current instance was started with incorrect command line parameters.*/
void displayCommandLineInstructions(){
    std::cout<<std::endl<<"VERSION "<<VERSION<<" COMMAND LINE INSTRUCTIONS"<<std::endl;
    std::cout<<TAB1<<"1. Six command line parameters are required. They can be supplied in any order."<<std::endl;
    std::cout<<TAB1<<"2. Parameter names are case sensitive."<<std::endl;
    std::cout<<TAB1<<"3. Parameters must be specified as ParemeterName=ParameterValue. No spaces are allowed around the '=' sign."<<std::endl;
    std::cout<<TAB1<<"4. Parameters must be separated by space."<<std::endl;
    std::cout<<TAB1<<"5. Probability Right (PRight) and ProbabilityLeft (PLeft) can be specified as decimal numbers or as integers."<<std::endl;
    std::cout<<TAB1<<"6. The ProbabilityScaleFactor (PScaleFactor) must be set to at least the greater of the number of decimal points used for PRight and PLeft."<<std::endl;
    std::cout<<TAB1<<"7. Steps cannot exceed "<<MAXIMUM_STEPS<<"."<<std::endl;
    std::cout<<TAB1<<"8. The product of Steps*Solutions must not exceed "<<MAXIMUM_SOLUTION_STEPS<<"."<<std::endl;
    std::cout<<TAB1<<"9. Using a new value of Steps may require a change to COMPRESSION_FACTOR in RandomWalkCommonHeader.h followed by a recompile. See RandomWalkCommonHeader.h for guidance."<<std::endl;
    std::cout<<TAB1<<"10. Action may take the value 'serialise', RAM or 'load'."<<std::endl;
    std::cout<<TAB1<<"11. Running the programme with Action=serialise will result in the creation of file Grid.Map."<<std::endl;
    std::cout<<TAB1<<"12. Running the programme with inconsistent Steps and Grid.Map file will result in an error."<<std::endl;
    std::cout<<TAB1<<"12. Running the programme with Action=RAM will result not result in or require the creation of file Grid.Map"<<std::endl;
    std::cout<<TAB1<<"13. Running the programme with inconsistent Steps and Grid.Map file will result in an error."<<std::endl;
    std::cout<<TAB1<<"14. Running the programme with Action=load and no Grid.Map file present is an uncontrolled condition and the programme will crash."<<std::endl;
    std::cout<<TAB1<<"15. Action=serialise, Action=RAM and Action=load give the same results. Programme execution with Action=load will be quicker."<<std::endl;
    std::cout<<TAB1<<"16. Additional functionality is enabled / disabled by parameters specified in RandomWalkCommonHeader.h. Enabling / disabling functionality in this way requires recompilation."<<std::endl;
    std::cout<<TAB1<<"17. Example: ~/Development/RandomWalk/run Solutions=1000 PRight=33 PScaleFactor=0 Steps=2000 Action=load PLeft=33."<<std::endl;
   
    return;
    }

// Convert relevant run data into string for Histogram File Name
std::string getHistogramFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string &PRightAsText, std::string &PLeftAsText, unsigned short int Thread){
    size_t Index = 0; 
    std::string HistogramFileName = "Histogram_TH";

    HistogramFileName = HistogramFileName +to_string(Thread)+ "ST"+ to_string(Steps) + "SW" + to_string(SolutionsWanted) + PRightAsText + PLeftAsText;

    while(TRUE){
        Index = HistogramFileName.find("=", Index);
        if(Index == std::string::npos) break;
        HistogramFileName.replace(Index, 1, "");
        Index += 1;
        } 

    Index = 0;
    while(TRUE){
        Index = HistogramFileName.find(".", Index);
        if(Index == std::string::npos) break;
        HistogramFileName.replace(Index, 1, "dot");
        Index += 3;
        } 

    Index = 0;
    while(TRUE){
        Index = HistogramFileName.find("PRight", Index);
        if(Index == std::string::npos) break;
        HistogramFileName.replace(Index, 6, "PR");

        Index = HistogramFileName.find("PLeft", Index);
        if(Index == std::string::npos) break;
        HistogramFileName.replace(Index, 5, "PL"); break;
        } 

    HistogramFileName = HistogramFileName + ".csv"; 

    return HistogramFileName;
    }
   
// Convert relevant run data into string for Analytics File Name 
std::string getAnalyticFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string &PRightAsText, std::string &PLeftAsText, unsigned short int Thread){
    size_t Index = 0; 
    std::string AnalyticFileName = "Analytics_TH";

    AnalyticFileName = AnalyticFileName +to_string(Thread)+ "ST"+ to_string(Steps) + "SW" + to_string(SolutionsWanted) + PRightAsText + PLeftAsText;

    while(TRUE){
        Index = AnalyticFileName.find("=", Index);
        if(Index == std::string::npos) break;
        AnalyticFileName.replace(Index, 1, "");
        Index += 1;
        } 

    Index = 0;
    while(TRUE){
        Index =AnalyticFileName.find(".", Index);
        if(Index == std::string::npos) break;
        AnalyticFileName.replace(Index, 1, "dot");
        Index += 3;
        } 

    Index = 0;
    while(TRUE){
        Index = AnalyticFileName.find("PRight", Index);
        if(Index == std::string::npos) break;
        AnalyticFileName.replace(Index, 6, "PR");

        Index = AnalyticFileName.find("PLeft", Index);
        if(Index == std::string::npos) break;
        AnalyticFileName.replace(Index, 5, "PL"); break;
        } 

    AnalyticFileName = AnalyticFileName + ".csv"; 

    return AnalyticFileName;
    }

// Convert relevant run data into string for Winding Angle File Name
std::string getWindingAngleFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string &PRightAsText, std::string &PLeftAsText, unsigned short int Thread){
    size_t Index = 0; 
    std::string WindingAngleFileName = "WindingAngles_TH";

    WindingAngleFileName = WindingAngleFileName +to_string(Thread)+ "ST"+ to_string(Steps) + "SW" + to_string(SolutionsWanted) + PRightAsText + PLeftAsText;

    while(TRUE){
        Index = WindingAngleFileName.find("=", Index);
        if(Index == std::string::npos) break;
        WindingAngleFileName.replace(Index, 1, "");
        Index += 1;
        } 

    Index = 0;
    while(TRUE){
        Index = WindingAngleFileName.find(".", Index);
        if(Index == std::string::npos) break;
        WindingAngleFileName.replace(Index, 1, "dot");
        Index += 3;
        } 

    Index = 0;
    while(TRUE){
        Index = WindingAngleFileName.find("PRight", Index);
        if(Index == std::string::npos) break;
        WindingAngleFileName.replace(Index, 6, "PR");

        Index = WindingAngleFileName.find("PLeft", Index);
        if(Index == std::string::npos) break;
        WindingAngleFileName.replace(Index, 5, "PL"); break;
        } 

    WindingAngleFileName = WindingAngleFileName + ".csv"; 

    return WindingAngleFileName; 
    }

/* Processes the arguments passed to the programme from the command ine.
   It is called from main()*/
int processCommandLine(int argC, char** argV, unsigned int& Steps, unsigned int& SolutionsWanted, float& ProbabilityRight, float& ProbabilityLeft,
    unsigned short int& ProbabilityScaleFactor, std::string& Action, std::string& PLeftAsText, std::string& PRightAsText){
    std::string Parameter;
    std::string ParameterValuePair[6][2];
    std::string Text;
    unsigned short int ActionParameterCount = 0;
    unsigned short int Item = 0;
    unsigned short int ParametersFound = 0;
    unsigned short int ParameterNumber;
    unsigned short int ParametersSought = 6;
    unsigned short int PLeftParameterCount = 0;
    unsigned short int PRightParameterCount = 0;
    unsigned short int PScaleFactorParameterCount = 0;
    unsigned short int SolutionsParameterCount = 0;
    unsigned short int StepsParameterCount = 0;

    if(argC != ParametersSought+1){
        std::cout<<TAB1<<"ERROR: "<<ParametersSought<<" command line parameters expected. "<<argC-1<<" command line parameters identified."<<std::endl; 
        return FALSE;
        }

    for(ParameterNumber = 1; ParameterNumber < argC; ParameterNumber++){
        istringstream NextPair(argV[ParameterNumber]);
        Item = 0;
   
        while(getline(NextPair, Text, '=')){
            ParameterValuePair[ParameterNumber-1][Item] = Text;
            Item++;
            }
         
        if(ParameterValuePair[ParameterNumber-1][0] == "Steps"){
            Steps = std::stol(ParameterValuePair[ParameterNumber-1][1]);
            ParametersFound++;
            StepsParameterCount++;
            }
        else if(ParameterValuePair[ParameterNumber-1][0] == "Solutions"){
            SolutionsWanted = std::stol(ParameterValuePair[ParameterNumber-1][1]);
            ParametersFound++;
            SolutionsParameterCount++;
            }
        else if(ParameterValuePair[ParameterNumber-1][0] == "PRight"){
            ProbabilityRight = std::stof(ParameterValuePair[ParameterNumber-1][1]);
            ParametersFound++;
            PRightParameterCount++;
            PRightAsText = argV[ParameterNumber];
            }
        else if(ParameterValuePair[ParameterNumber-1][0] == "PLeft"){
            ProbabilityLeft = std::stof(ParameterValuePair[ParameterNumber-1][1]);
            ParametersFound++;
            PLeftParameterCount++;
            PLeftAsText = argV[ParameterNumber];
            }
        else if(ParameterValuePair[ParameterNumber-1][0] == "PScaleFactor"){
            ProbabilityScaleFactor = std::stoi(ParameterValuePair[ParameterNumber-1][1]);
            ParametersFound++;
            PScaleFactorParameterCount++;
            }
        else if(ParameterValuePair[ParameterNumber-1][0] == "Action"){
            Action = ParameterValuePair[ParameterNumber-1][1];
            ParametersFound++;
            ActionParameterCount++;
            }
        else{
            std::cout<<TAB1<<"ERROR: Unrecognised parameter: "<<ParameterValuePair[ParameterNumber-1][0]<<"."<<std::endl;
            return FALSE;
            }
        }

    if(Steps > MAXIMUM_STEPS){
        std::cout<<TAB1<<"ERROR: Steps of "<<Steps<<" exceeds supported upper limit of "<<MAXIMUM_STEPS<<"."<<std::endl;
        return FALSE;
        }

    if(Steps*SolutionsWanted > MAXIMUM_SOLUTION_STEPS){
        std::cout<<TAB1<<"ERROR: Solution steps (Steps*SolutionsWanted) of "<<Steps*SolutionsWanted<<" exceeds supported upper limit of "<<MAXIMUM_SOLUTION_STEPS<<"."<<std::endl;
        return FALSE;
        }

    if(Action != "serialise" && Action != "load" && Action != "RAM" ){
        std::cout<<TAB1<<"ERROR: Invalid value of Action specified: "<<Action<<"."<<std::endl;
        return FALSE;
        }

    if(StepsParameterCount > 1 || SolutionsParameterCount > 1 || PRightParameterCount > 1 || PLeftParameterCount > 1 || PScaleFactorParameterCount > 1 || ActionParameterCount > 1 ){
        std::cout<<TAB1<<"ERROR: At least one parameter specified multiple times."<<std::endl;
        return FALSE;
        }
        
    displayProgrammeParameters(Steps, SolutionsWanted, ProbabilityRight, ProbabilityLeft, ProbabilityScaleFactor, Action);

    return TRUE;
    }

void writeWindingAnglesToStream(std::string WindingAngleResults, std::vector<float>& WindingAngles){
    ofstream WindingAnglesOutput(WindingAngleResults);
    
    std::cout<<TAB1<<WindingAngleResults<<std::endl;
      
	if (!WindingAnglesOutput){
        std::cout<<"Failed to open the file."<<std::endl;
        }
    else{
        for (unsigned i=0; i<WindingAngles.size(); i++) WindingAnglesOutput<<"\n"<< WindingAngles.at(i);
        WindingAnglesOutput.close();
        }
    
    return;
    }
