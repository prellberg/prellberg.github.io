#ifndef RandomWalkUtilities_h
    #define RandomWalkUtilities_h

    #include "RandomWalkCommonHeader.h"

    void displayCommandLineInstructions();
    void displayProgrammeParameters(unsigned int& Steps, unsigned int& SolutionsWanted, float& ProbabilityRight, float& ProbabilityLeft, unsigned short int& ProbabilityScaleFactor, std::string& Action);
    std::string getAnalyticFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string &PRightAsText, std::string &PLeftAsText, unsigned short int Thread);
    std::string getHistogramFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string &PRightAsText, std::string &PLeftAsText, unsigned short int Thread);
    std::string getWindingAngleFileName(unsigned int Steps, unsigned int SolutionsWanted, std::string& PRightAsText, std::string& PLeftAsText, unsigned short int Thread);
    int processCommandLine(int argC, char** argV, unsigned int& Steps, unsigned int& SolutionsWanted, float& ProbabilityRight, float& ProbabilityLeft,
        unsigned short int& ProbabilityScaleFactor, std::string& Action, std::string& PLeftAsText, std::string& PRightAsText);
    void writeWindingAnglesToStream(std::string WindingAngleResults, std::vector<float>& WindingAngles);
#endif