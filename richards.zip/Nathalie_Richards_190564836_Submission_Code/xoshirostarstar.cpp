/*  Written in 2018 by David Blackman and Sebastiano Vigna (vigna@acm.org)

To the extent possible under law, the author has dedicated all copyright
and related and neighboring rights to this software to the public domain
worldwide. This software is distributed without any warranty.

See <http://creativecommons.org/publicdomain/zero/1.0/>. */

#include <stdint.h>

/* This is xoshiro256** 1.0, one of our all-purpose, rock-solid
   generators. It has excellent (sub-ns) speed, a state (256 bits) that is
   large enough for any parallel application, and it passes all tests we
   are aware of.

   For generating just floating-point numbers, xoshiro256+ is even faster.

   The state must be seeded so that it is not everywhere zero. If you have
   a 64-bit seed, we suggest to seed a splitmix64 generator and use its
   output to fill s. */

/*  RandomWalk Modifications:
	1. Using variable name xoshiro256ss_state in place of s. 
    2. jump() and long_jump() functions removed.
	3. next() renamed nextRandomDirectionChange.
	4. Replace uint64_t with unsigned long.
	5. Replaced int with unsigned  int.
	6. nextRandomDirectionChange() modified to return number between 0 and passed in Range-1.
	7. Custom RandomWalk initialisation function added.*/

static inline unsigned long rotl(const unsigned long x, signed short int k){
	return (x << k) | (x >> (64 - k));
    }

static unsigned long xoshiro256ss_state[4]; // Replaces static uint64_t s[4];

unsigned int nextRandomDirectionChange(unsigned int Range){
	const unsigned int result = (rotl(xoshiro256ss_state[1] * 5, 7) * 9) % Range;

	const unsigned long t = xoshiro256ss_state[1] << 17;

	xoshiro256ss_state[2] ^= xoshiro256ss_state[0];
	xoshiro256ss_state[3] ^= xoshiro256ss_state[1];
	xoshiro256ss_state[1] ^= xoshiro256ss_state[2];
	xoshiro256ss_state[0] ^= xoshiro256ss_state[3];

	xoshiro256ss_state[2] ^= t;

	xoshiro256ss_state[3] = rotl(xoshiro256ss_state[3], 45);

	return result;
	}

// Custom RandomWalk initialisation function added.
#include <stdlib.h>
void xoshiro256ss_init(){
	xoshiro256ss_state[0] = rand();
	xoshiro256ss_state[1] = rand();
	xoshiro256ss_state[2] = rand();
	xoshiro256ss_state[3] = rand();

	return;
	}